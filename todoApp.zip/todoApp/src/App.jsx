import { useState } from "react";

function App() {
  const [tasks, setTasks] = useState([]);
  const [inputValue,setInputValue] = useState("")
  const [isEditing,setIsEditing] = useState(false)
  const [editingValue,setEditingValue] = useState("")

  const handleChange=(event)=>{
    setInputValue(event.target.value)
  }
  const handleAddtask=()=>{
    //for editing
    if(isEditing){
      const index = tasks.indexOf(editingValue)
      const updatedTasks = [...tasks]
      updatedTasks.splice(index , 1 , inputValue)
      setTasks(updatedTasks)
    }
    else{
      setTasks((prevtasks)=>[...prevtasks,inputValue])
    }
    setIsEditing(false)
    //-------
    
    setInputValue("")
  }
  const handleDelete=(task)=>{
    const updatedTasks = tasks.filter((current)=>current !== task)
    setTasks(updatedTasks)
  }
  const handleEdit=(task)=>{
    setIsEditing(true)
    setInputValue(task)
    setEditingValue(task)
  }

  return (
    <div className="h-screen w-screen bg-violet-200 flex flex-col justify-center items-center">
      <h2 className="text-3xl font-bold m-6">Todo app</h2>

      <div>
        <input
          onChange={handleChange}
          value={inputValue}
          placeholder="write Todo's"
          type="text"
          className="border-1 w-[40vw] h-12 bg-white p-2 mb-6 mr-3 rounded-md"
        />
        <button onClick={handleAddtask} className="border-1 bg-violet-50 p-2 rounded-md h-12 ">
          {isEditing ? "save" : "add task "}
        </button>
      </div>

      <ul>
        {tasks.map((task,index) => {
          return (
            <li key={index} className="mb-3 bg-white w-200 flex justify-between items-center rounded-xl p-2 overflow-auto">
              <input type="checkbox"  />
              {task}
              <span>
                <button onClick={()=>handleEdit(task)} className="border-1 bg-violet-50 p-1 rounded-md ml-3 mr-3">
                  Edit
                </button>
                <button onClick={()=>handleDelete(task)} className="border-1 bg-violet-50 p-1 rounded-md mr-3">
                  Delete
                </button>
                
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
export default App;
